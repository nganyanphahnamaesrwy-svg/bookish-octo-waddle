import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Inspection Records Table
export const inspections = pgTable("inspections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  carNo: text("car_no").notNull(),
  driver: text("driver").notNull(),
  inspectionDate: text("inspection_date").notNull(),
  vehicleType: text("vehicle_type").notNull(),
  currentMileage: integer("current_mileage").notNull(),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertInspectionSchema = createInsertSchema(inspections).omit({
  id: true,
  createdAt: true,
});

export type InsertInspection = z.infer<typeof insertInspectionSchema>;
export type Inspection = typeof inspections.$inferSelect;

// Inspection Form Schema for Google Sheets
export const inspectionFormSchema = z.object({
  vehicleLicensePlate: z.string().min(1, "กรุณาเลือกยานพาหนะ"),
  vehicleType: z.string(),
  inspector: z.string().min(1, "กรุณาเลือกผู้ตรวจเช็ค"),
  inspectionDate: z.string(),
  currentMileage: z.number().min(0, "กรุณากรอกเลขไมล์"),
  
  // Engine System
  engineOilLevel: z.enum(["ปกติ", "ผิดปกติ"]),
  engineSound: z.enum(["ปกติ", "ผิดปกติ"]),
  beltCondition: z.enum(["ปกติ", "ผิดปกติ"]),
  oilLeakage: z.enum(["ปกติ", "ผิดปกติ"]),
  
  // Fluids
  coolantLevel: z.enum(["ปกติ", "ผิดปกติ"]),
  brakeFluidLevel: z.enum(["ปกติ", "ผิดปกติ"]),
  powerSteeringFluid: z.enum(["ปกติ", "ผิดปกติ"]),
  batteryWater: z.enum(["ปกติ", "ผิดปกติ"]),
  washerFluid: z.enum(["ปกติ", "ผิดปกติ"]),
  
  // Electrical & AC
  headlights: z.enum(["ปกติ", "ผิดปกติ"]),
  turnSignals: z.enum(["ปกติ", "ผิดปกติ"]),
  brakeLights: z.enum(["ปกติ", "ผิดปกติ"]),
  airConditioning: z.enum(["ปกติ", "ผิดปกติ"]),
  horn: z.enum(["ปกติ", "ผิดปกติ"]),
  wipers: z.enum(["ปกติ", "ผิดปกติ"]),
  
  // Exterior & Interior
  tireCondition: z.enum(["ปกติ", "ผิดปกติ"]),
  mirrors: z.enum(["ปกติ", "ผิดปกติ"]),
  seatbelts: z.enum(["ปกติ", "ผิดปกติ"]),
  bodyScratches: z.enum(["ปกติ", "ผิดปกติ"]),
  interiorCleanliness: z.enum(["ปกติ", "ผิดปกติ"]),
  
  // Emergency Equipment
  spareTire: z.enum(["ปกติ", "ผิดปกติ"]),
  jackAndTools: z.enum(["ปกติ", "ผิดปกติ"]),
  flashlight: z.enum(["ปกติ", "ผิดปกติ"]),
  fireExtinguisher: z.enum(["ปกติ", "ผิดปกติ"]),
  firstAidKit: z.enum(["ปกติ", "ผิดปกติ"]),
  
  // Ambulance Equipment (optional - only for ambulance types)
  oxygenTank: z.enum(["ปกติ", "ผิดปกติ"]).optional(),
  suctionDevice: z.enum(["ปกติ", "ผิดปกติ"]).optional(),
  spinalBoard: z.enum(["ปกติ", "ผิดปกติ"]).optional(),
  stretcher: z.enum(["ปกติ", "ผิดปกติ"]).optional(),
  stairChair: z.enum(["ปกติ", "ผิดปกติ"]).optional(),
  
  // Notes
  additionalNotes: z.string().optional(),
});

export type InspectionForm = z.infer<typeof inspectionFormSchema>;
