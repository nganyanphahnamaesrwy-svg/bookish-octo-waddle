import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { inspectionFormSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // API: Submit Inspection Form to Google Sheets and Database
  app.post("/api/inspection", async (req, res) => {
    try {
      // Validate request body
      const validationResult = inspectionFormSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          success: false, 
          error: "ข้อมูลไม่ถูกต้อง", 
          details: validationResult.error.flatten() 
        });
      }

      const formData = validationResult.data;
      
      // Save to database
      try {
        await storage.createInspection({
          carNo: formData.vehicleLicensePlate,
          driver: formData.inspector,
          inspectionDate: formData.inspectionDate,
          vehicleType: formData.vehicleType,
          currentMileage: formData.currentMileage,
        });
      } catch (dbError) {
        console.error("Database save error:", dbError);
      }

      // Get Google Sheets Script URL from environment
      const scriptUrl = process.env.GOOGLE_SHEETS_SCRIPT_URL;
      
      if (scriptUrl) {
        // Prepare data for Google Sheets (match the expected columns: car_no, driver, time, status)
        const sheetData = {
          car_no: formData.vehicleLicensePlate,
          driver: formData.inspector,
          time: new Date().toLocaleString("th-TH", { timeZone: "Asia/Bangkok" }),
          status: "ตรวจเช็คเสร็จสิ้น",
        };

        // Send to Google Sheets via Apps Script
        try {
          await fetch(scriptUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(sheetData),
          });
        } catch (googleError) {
          console.error("Google Sheets error:", googleError);
        }
      }

      return res.json({ 
        success: true, 
        message: "บันทึกข้อมูลสำเร็จ" 
      });

    } catch (error) {
      console.error("Inspection submission error:", error);
      return res.status(500).json({ 
        success: false, 
        error: "เกิดข้อผิดพลาดในการบันทึกข้อมูล" 
      });
    }
  });

  // API: Get all inspection records
  app.get("/api/inspections", async (req, res) => {
    try {
      const records = await storage.getInspections();
      return res.json({ 
        success: true, 
        data: records 
      });
    } catch (error) {
      console.error("Get inspections error:", error);
      return res.status(500).json({ 
        success: false, 
        error: "เกิดข้อผิดพลาดในการดึงข้อมูล" 
      });
    }
  });

  // API: Delete all inspection records
  app.delete("/api/inspections", async (req, res) => {
    try {
      const deletedCount = await storage.deleteAllInspections();
      return res.json({ 
        success: true, 
        message: `ลบข้อมูลทั้งหมด ${deletedCount} รายการสำเร็จ` 
      });
    } catch (error) {
      console.error("Delete inspections error:", error);
      return res.status(500).json({ 
        success: false, 
        error: "เกิดข้อผิดพลาดในการลบข้อมูล" 
      });
    }
  });

  return httpServer;
}
