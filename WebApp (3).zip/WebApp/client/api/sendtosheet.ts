export async function sendToSheet(moduleName: string, payload: any) {
  const url = "https://script.google.com/macros/s/AKfycbwX2zj-LYpZFEkAPQqQvj7CQ1qW_gCE60S50U8SuMkYti8Bi8KJj_wSLGRGX_oyyPol/exec";

  const data = {
    module: moduleName,
    ...payload,
  };

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    return await res.json();
  } catch (err) {
    console.error("Error sending to Google Sheet:", err);
  }
}
