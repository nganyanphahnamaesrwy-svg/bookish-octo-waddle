import Layout from "@/components/layout/Layout";
import { initialVehicles, maintenanceHistory, MaintenanceRecord } from "@/lib/mockData";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, Wrench, History, CheckCircle2, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Maintenance() {
  // In a real app, we would calculate alerts dynamically
  const alerts = initialVehicles.filter(v => {
    const distanceToService = v.nextMaintenanceDue - v.mileage;
    return distanceToService <= 1000;
  }).map(v => ({
    ...v,
    distanceToService: v.nextMaintenanceDue - v.mileage
  }));

  const inRepair = initialVehicles.filter(v => v.status === "Maintenance");

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">การซ่อมบำรุง</h1>
          <p className="text-muted-foreground">ติดตามสถานะการซ่อม แจ้งเตือนระยะ และประวัติการบำรุงรักษา</p>
        </div>

        {/* Alerts Section */}
        {alerts.length > 0 && (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {alerts.map(vehicle => (
              <Card key={vehicle.id} className="border-l-4 border-l-amber-500 shadow-sm animate-in slide-in-from-left-2">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base font-bold">{vehicle.licensePlate}</CardTitle>
                    <AlertCircle className="h-5 w-5 text-amber-500" />
                  </div>
                  <CardDescription>{vehicle.type}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">อีก {vehicle.distanceToService} กม.</span>
                      <span className="font-medium text-amber-600">ถึงกำหนดเช็คระยะ</span>
                    </div>
                    <Progress value={80} className="h-2 bg-amber-100 [&>div]:bg-amber-500" />
                    <div className="text-xs text-muted-foreground pt-1">
                      เลขไมล์ปัจจุบัน: {vehicle.mileage.toLocaleString()} กม.
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <div className="grid gap-6 md:grid-cols-2">
          {/* Current Repairs */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Wrench className="h-5 w-5 text-primary" />
                <CardTitle>รถที่กำลังซ่อมบำรุง</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              {inRepair.length > 0 ? (
                <div className="space-y-4">
                  {inRepair.map(v => (
                    <div key={v.id} className="flex items-center justify-between p-4 bg-muted/40 rounded-lg border">
                      <div>
                         <div className="font-bold">{v.licensePlate}</div>
                         <div className="text-sm text-muted-foreground">{v.type}</div>
                      </div>
                      <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-200 border-amber-200">
                        กำลังดำเนินการ
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
                  <CheckCircle2 className="h-8 w-8 mb-2 opacity-20" />
                  <p>ไม่มีรถที่กำลังซ่อมบำรุง</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Cost Summary (Mock) */}
          <Card>
            <CardHeader>
              <CardTitle>สรุปค่าใช้จ่ายซ่อมบำรุง</CardTitle>
              <CardDescription>ปีงบประมาณ 2568</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-end border-b pb-2">
                  <span className="text-sm font-medium">งบประมาณตั้งต้น</span>
                  <span className="text-lg font-bold">500,000 ฿</span>
                </div>
                <div className="flex justify-between items-end border-b pb-2">
                  <span className="text-sm font-medium">ใช้ไปแล้ว</span>
                  <span className="text-lg font-bold text-blue-600">145,500 ฿</span>
                </div>
                <div className="flex justify-between items-end pb-2">
                  <span className="text-sm font-medium">คงเหลือ</span>
                  <span className="text-lg font-bold text-emerald-600">354,500 ฿</span>
                </div>
                <Progress value={29} className="h-3" />
                <p className="text-xs text-right text-muted-foreground">ใช้ไป 29% ของงบประมาณ</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* History Table */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <History className="h-5 w-5 text-primary" />
              <CardTitle>ประวัติการซ่อมบำรุงล่าสุด</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>วันที่</TableHead>
                  <TableHead>ทะเบียนรถ</TableHead>
                  <TableHead>รายการ</TableHead>
                  <TableHead>ประเภท</TableHead>
                  <TableHead className="text-right">ค่าใช้จ่าย (บาท)</TableHead>
                  <TableHead className="text-right">เลขไมล์</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {maintenanceHistory.map((record) => {
                  const vehicle = initialVehicles.find(v => v.id === record.vehicleId);
                  return (
                    <TableRow key={record.id}>
                      <TableCell className="font-medium">{new Date(record.date).toLocaleDateString('th-TH')}</TableCell>
                      <TableCell className="font-mono">{vehicle?.licensePlate || "Unknown"}</TableCell>
                      <TableCell>{record.description}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn(
                          record.type === "Accident" ? "border-red-200 bg-red-50 text-red-700" : 
                          record.type === "Repair" ? "border-amber-200 bg-amber-50 text-amber-700" :
                          "border-blue-200 bg-blue-50 text-blue-700"
                        )}>
                          {record.type === "Routine" ? "เช็คระยะ" : 
                           record.type === "Repair" ? "ซ่อมทั่วไป" : "อุบัติเหตุ"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-mono">{record.cost.toLocaleString()}</TableCell>
                      <TableCell className="text-right text-muted-foreground">{record.mileageAtService.toLocaleString()}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
