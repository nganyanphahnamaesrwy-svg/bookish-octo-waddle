import Layout from "@/components/layout/Layout";
import { useState } from "react";
import { useLocation } from "wouter";
import { initialVehicles, defaultInspectors } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { ClipboardCheck, AlertTriangle, Save, Gauge, CheckCircle2, Loader2, Settings } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

type ChecklistValues = Record<string, "ปกติ" | "ผิดปกติ">;

export default function InspectionForm() {
  const [, setLocation] = useLocation();
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>("");
  const [currentMileage, setCurrentMileage] = useState<number>(0);
  const [inspector, setInspector] = useState<string>("");
  const [inspectionDate, setInspectionDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [additionalNotes, setAdditionalNotes] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [inspectors, setInspectors] = useState<string[]>(defaultInspectors);
  const [newInspectorName, setNewInspectorName] = useState<string>("");
  const [isManagingInspectors, setIsManagingInspectors] = useState(false);

  const handleAddInspector = () => {
    if (!newInspectorName.trim()) {
      toast({ title: "ข้อมูลไม่ครบ", description: "กรุณากรอกชื่อผู้ตรวจเช็ค", variant: "destructive" });
      return;
    }
    if (inspectors.includes(newInspectorName)) {
      toast({ title: "ชื่อซ้ำ", description: "ชื่อผู้ตรวจเช็คนี้มีอยู่แล้ว", variant: "destructive" });
      return;
    }
    setInspectors([...inspectors, newInspectorName]);
    setNewInspectorName("");
    toast({ title: "เพิ่มสำเร็จ", description: `เพิ่ม ${newInspectorName} เข้าสู่รายชื่อผู้ตรวจเช็ค` });
  };

  const handleDeleteInspector = (name: string) => {
    setInspectors(inspectors.filter(i => i !== name));
    toast({ title: "ลบสำเร็จ", description: `ลบ ${name} ออกจากรายชื่อแล้ว` });
  };
  
  // Checklist states
  const [checklistValues, setChecklistValues] = useState<ChecklistValues>({
    // Engine System
    engineOilLevel: "ปกติ",
    engineSound: "ปกติ",
    beltCondition: "ปกติ",
    oilLeakage: "ปกติ",
    // Fluids
    coolantLevel: "ปกติ",
    brakeFluidLevel: "ปกติ",
    powerSteeringFluid: "ปกติ",
    batteryWater: "ปกติ",
    washerFluid: "ปกติ",
    // Electrical & AC
    headlights: "ปกติ",
    turnSignals: "ปกติ",
    brakeLights: "ปกติ",
    airConditioning: "ปกติ",
    horn: "ปกติ",
    wipers: "ปกติ",
    // Exterior & Interior
    tireCondition: "ปกติ",
    mirrors: "ปกติ",
    seatbelts: "ปกติ",
    bodyScratches: "ปกติ",
    interiorCleanliness: "ปกติ",
    // Emergency Equipment
    spareTire: "ปกติ",
    jackAndTools: "ปกติ",
    flashlight: "ปกติ",
    fireExtinguisher: "ปกติ",
    firstAidKit: "ปกติ",
    // Ambulance Equipment
    oxygenTank: "ปกติ",
    suctionDevice: "ปกติ",
    spinalBoard: "ปกติ",
    stretcher: "ปกติ",
    stairChair: "ปกติ",
  });

  const [vehicleType, setVehicleType] = useState<string>("");
  const selectedVehicle = initialVehicles.find(v => v.id === selectedVehicleId);

  if (selectedVehicle && selectedVehicle.type !== vehicleType) {
    setVehicleType(selectedVehicle.type);
  }
  
  const remainingDistance = selectedVehicle 
    ? selectedVehicle.nextMaintenanceDue - currentMileage 
    : 0;

  const isServiceDue = selectedVehicle && remainingDistance <= 1000;
  const isAmbulance = vehicleType === "Ambulance" || vehicleType === "Pickup 4x4 Ambulance";

  const handleChecklistChange = (key: string, value: "ปกติ" | "ผิดปกติ") => {
    setChecklistValues(prev => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedVehicleId || !inspector || !currentMileage) {
      toast({
        title: "ข้อมูลไม่ครบถ้วน",
        description: "กรุณากรอกข้อมูลยานพาหนะ ผู้ตรวจ และเลขไมล์ให้ครบถ้วน",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const formData = {
        vehicleLicensePlate: selectedVehicle?.licensePlate || "",
        vehicleType: vehicleType,
        inspector: inspector,
        inspectionDate: inspectionDate,
        currentMileage: currentMileage,
        ...checklistValues,
        additionalNotes: additionalNotes,
      };

      const response = await fetch("/api/inspection", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "บันทึกข้อมูลสำเร็จ",
          description: `บันทึกการตรวจเช็คสภาพรถทะเบียน ${selectedVehicle?.licensePlate} ไปยัง Google Sheets เรียบร้อยแล้ว`,
        });
        setTimeout(() => setLocation("/maintenance"), 1500);
      } else {
        toast({
          title: "เกิดข้อผิดพลาด",
          description: result.error || "ไม่สามารถบันทึกข้อมูลได้",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Submit error:", error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8 pb-10">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-primary flex items-center gap-3">
              <ClipboardCheck className="h-8 w-8" />
              แบบฟอร์มตรวจเช็คสภาพรถ
            </h1>
            <p className="text-muted-foreground mt-2">
              บันทึกผลการตรวจสอบสภาพรถประจำวันและก่อนการใช้งาน (ข้อมูลจะถูกบันทึกลง Google Sheets)
            </p>
          </div>
          <Dialog open={isManagingInspectors} onOpenChange={setIsManagingInspectors}>
            <DialogTrigger asChild>
              <Button variant="outline" size="icon" className="gap-2" data-testid="button-manage-inspectors">
                <Settings className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>จัดการรายชื่อผู้ตรวจเช็ค</DialogTitle>
                <DialogDescription>เพิ่มหรือลบชื่อผู้ตรวจเช็คใหม่</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>เพิ่มชื่อผู้ตรวจเช็ค</Label>
                  <div className="flex gap-2">
                    <Input 
                      placeholder="ชื่อผู้ตรวจเช็ค" 
                      value={newInspectorName}
                      onChange={(e) => setNewInspectorName(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleAddInspector()}
                      data-testid="input-new-inspector"
                    />
                    <Button onClick={handleAddInspector} size="sm" data-testid="button-add-inspector">เพิ่ม</Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>รายชื่อปัจจุบัน ({inspectors.length})</Label>
                  <div className="border rounded-lg p-3 max-h-64 overflow-y-auto space-y-2">
                    {inspectors.length === 0 ? (
                      <p className="text-sm text-muted-foreground">ไม่มีรายชื่อผู้ตรวจเช็ค</p>
                    ) : (
                      inspectors.map((name) => (
                        <div key={name} className="flex items-center justify-between bg-muted p-2 rounded text-sm" data-testid={`inspector-item-${name}`}>
                          <span>{name}</span>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleDeleteInspector(name)}
                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                            data-testid={`button-delete-inspector-${name}`}
                          >
                            ลบ
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Vehicle & Driver Info */}
          <Card>
            <CardHeader>
              <CardTitle>ข้อมูลทั่วไป</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label>เลือกยานพาหนะ</Label>
                <Select onValueChange={(val) => {
                  setSelectedVehicleId(val);
                  const v = initialVehicles.find(v => v.id === val);
                  if (v) setCurrentMileage(v.mileage);
                }}>
                  <SelectTrigger data-testid="select-vehicle">
                    <SelectValue placeholder="เลือกทะเบียนรถ" />
                  </SelectTrigger>
                  <SelectContent>
                    {initialVehicles.map(v => (
                      <SelectItem key={v.id} value={v.id}>
                        {v.licensePlate} - {v.type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>ผู้ตรวจเช็ค</Label>
                <Select onValueChange={setInspector}>
                  <SelectTrigger data-testid="select-inspector">
                    <SelectValue placeholder="เลือกชื่อผู้ตรวจ" />
                  </SelectTrigger>
                  <SelectContent>
                    {inspectors.map(name => (
                      <SelectItem key={name} value={name}>{name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>วันที่ตรวจ</Label>
                <Input 
                  type="date" 
                  value={inspectionDate}
                  onChange={(e) => setInspectionDate(e.target.value)}
                  data-testid="input-date"
                />
              </div>

              <div className="space-y-2">
                <Label>เลขไมล์ปัจจุบัน (กม.)</Label>
                <div className="relative">
                  <Gauge className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input 
                    type="number" 
                    className="pl-9" 
                    value={currentMileage}
                    onChange={(e) => setCurrentMileage(Number(e.target.value))}
                    data-testid="input-mileage"
                  />
                </div>
                {selectedVehicle && (
                  <div className={cn(
                    "text-sm mt-2 flex items-center gap-2 p-2 rounded-md border",
                    isServiceDue ? "bg-amber-50 border-amber-200 text-amber-800" : "bg-emerald-50 border-emerald-200 text-emerald-800"
                  )}>
                    {isServiceDue ? <AlertTriangle className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
                    <span>
                      เหลือระยะอีก {remainingDistance.toLocaleString()} กม. ก่อนเช็คระยะรอบถัดไป 
                      ({selectedVehicle.nextMaintenanceDue.toLocaleString()} กม.)
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Checklist Sections */}
          <div className="space-y-6">
             <ChecklistSection 
               title="1. ระบบเครื่องยนต์ (Engine System)" 
               items={[
                 { key: "engineOilLevel", label: "ระดับน้ำมันเครื่อง" },
                 { key: "engineSound", label: "เสียงการทำงานของเครื่องยนต์" },
                 { key: "beltCondition", label: "สภาพสายพานต่างๆ" },
                 { key: "oilLeakage", label: "การรั่วซึมของน้ำมันเครื่อง" },
               ]} 
               values={checklistValues}
               onChange={handleChecklistChange}
             />

             <ChecklistSection 
               title="2. ของเหลวทั้งหมด (All Fluids)" 
               items={[
                 { key: "coolantLevel", label: "ระดับน้ำหม้อน้ำ / น้ำยาหล่อเย็น" },
                 { key: "brakeFluidLevel", label: "ระดับน้ำมันเบรค / คลัทช์" },
                 { key: "powerSteeringFluid", label: "ระดับน้ำมันพวงมาลัยพาวเวอร์" },
                 { key: "batteryWater", label: "ระดับน้ำกลั่นแบตเตอรี่" },
                 { key: "washerFluid", label: "ระดับน้ำฉีดกระจก" },
               ]} 
               values={checklistValues}
               onChange={handleChecklistChange}
             />

             <ChecklistSection 
               title="3. ระบบไฟฟ้าและแอร์ (Electrical & AC)" 
               items={[
                 { key: "headlights", label: "ไฟหน้า (สูง/ต่ำ)" },
                 { key: "turnSignals", label: "ไฟเลี้ยว / ไฟฉุกเฉิน" },
                 { key: "brakeLights", label: "ไฟเบรค / ไฟถอยหลัง" },
                 { key: "airConditioning", label: "ระบบปรับอากาศ / ความเย็น" },
                 { key: "horn", label: "แตรรถ" },
                 { key: "wipers", label: "ที่ปัดน้ำฝน" },
               ]} 
               values={checklistValues}
               onChange={handleChecklistChange}
             />

             <ChecklistSection 
               title="4. ภายนอกและภายใน (Exterior & Interior)" 
               items={[
                 { key: "tireCondition", label: "สภาพยางรถยนต์ / แรงดันลมยาง" },
                 { key: "mirrors", label: "กระจกมองข้าง / มองหลัง" },
                 { key: "seatbelts", label: "เข็มขัดนิรภัย" },
                 { key: "bodyScratches", label: "รอยขีดข่วนรอบตัวรถ" },
                 { key: "interiorCleanliness", label: "ความสะอาดภายในห้องโดยสาร" },
               ]} 
               values={checklistValues}
               onChange={handleChecklistChange}
             />

             <ChecklistSection 
               title="5. อุปกรณ์ฉุกเฉิน (Emergency Equipment)" 
               items={[
                 { key: "spareTire", label: "ยางอะไหล่" },
                 { key: "jackAndTools", label: "แม่แรงและเครื่องมือถอดล้อ" },
                 { key: "flashlight", label: "ไฟฉาย" },
                 { key: "fireExtinguisher", label: "ถังดับเพลิง" },
                 { key: "firstAidKit", label: "ชุดปฐมพยาบาลเบื้องต้น" },
               ]} 
               values={checklistValues}
               onChange={handleChecklistChange}
             />

             {isAmbulance && (
               <ChecklistSection 
                 title="6. อุปกรณ์การแพทย์ฉุกเฉิน (Ambulance Equipment)" 
                 items={[
                   { key: "oxygenTank", label: "ชุดถังอ็อกซิเจน + เกจวัดความดัน" },
                   { key: "suctionDevice", label: "เครื่องดูดเสมหะแบบไฟฟ้า" },
                   { key: "spinalBoard", label: "แผ่นกระดานรองหลัง (Long Spinal Board)" },
                   { key: "stretcher", label: "เตียงเคลื่อนย้ายผู้ป่วย (Stretcher)" },
                   { key: "stairChair", label: "ล้อเข็นเคลื่อนย้าย/พับได้ (Stair Chair)" },
                 ]} 
                 values={checklistValues}
                 onChange={handleChecklistChange}
                 className="border-l-4 border-l-red-500"
               />
             )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>หมายเหตุเพิ่มเติม</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea 
                placeholder="ระบุความผิดปกติอื่นๆ หรือสิ่งที่ต้องซ่อมแซม..." 
                className="min-h-[100px]"
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                data-testid="input-notes"
              />
            </CardContent>
          </Card>

          <div className="flex justify-end gap-4 pt-4">
            <Button type="button" variant="outline" onClick={() => setLocation("/maintenance")} disabled={isSubmitting}>
              ยกเลิก
            </Button>
            <Button type="submit" size="lg" className="w-full md:w-auto gap-2" disabled={isSubmitting} data-testid="button-submit">
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  กำลังบันทึก...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  บันทึกผลการตรวจเช็ค
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </Layout>
  );
}

interface ChecklistItem {
  key: string;
  label: string;
}

interface ChecklistSectionProps {
  title: string;
  items: ChecklistItem[];
  values: ChecklistValues;
  onChange: (key: string, value: "ปกติ" | "ผิดปกติ") => void;
  className?: string;
}

function ChecklistSection({ title, items, values, onChange, className }: ChecklistSectionProps) {
  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {items.map((item) => (
            <div key={item.key} className="flex items-start md:items-center justify-between gap-4 border-b pb-3 last:border-0 last:pb-0">
              <Label className="font-normal text-base flex-1">{item.label}</Label>
              <RadioGroup 
                value={values[item.key]} 
                onValueChange={(val) => onChange(item.key, val as "ปกติ" | "ผิดปกติ")}
                className="flex flex-row gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem 
                    value="ปกติ" 
                    id={`${item.key}-pass`} 
                    className="text-emerald-600 border-emerald-600"
                    data-testid={`radio-${item.key}-pass`}
                  />
                  <Label htmlFor={`${item.key}-pass`} className="text-emerald-700 cursor-pointer">ปกติ</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem 
                    value="ผิดปกติ" 
                    id={`${item.key}-fail`} 
                    className="text-red-600 border-red-600"
                    data-testid={`radio-${item.key}-fail`}
                  />
                  <Label htmlFor={`${item.key}-fail`} className="text-red-700 cursor-pointer">ผิดปกติ</Label>
                </div>
              </RadioGroup>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
