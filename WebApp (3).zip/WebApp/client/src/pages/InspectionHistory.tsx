import Layout from "@/components/layout/Layout";
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { HistoryIcon, Calendar, Car, User, Gauge, Loader2, Trash2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface InspectionRecord {
  id: string;
  carNo: string;
  driver: string;
  inspectionDate: string;
  vehicleType: string;
  currentMileage: number;
  createdAt?: string;
}

export default function InspectionHistory() {
  const [records, setRecords] = useState<InspectionRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isResetting, setIsResetting] = useState(false);
  const [, setLocation] = useLocation();

  const fetchRecords = async () => {
    try {
      const response = await fetch("/api/inspections");
      const result = await response.json();
      
      if (result.success) {
        setRecords(result.data);
      }
    } catch (error) {
      console.error("Fetch error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRecords();
  }, []);

  const handleResetData = async () => {
    setIsResetting(true);
    try {
      const response = await fetch("/api/inspections", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const result = await response.json();

      if (result.success) {
        toast({
          title: "ลบข้อมูลสำเร็จ",
          description: result.message,
        });
        setRecords([]);
      } else {
        toast({
          title: "เกิดข้อผิดพลาด",
          description: result.error,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Reset error:", error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถลบข้อมูลได้",
        variant: "destructive"
      });
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <Layout>
      <div className="max-w-5xl mx-auto space-y-8 pb-10">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-primary flex items-center gap-3">
              <HistoryIcon className="h-8 w-8" />
              ประวัติการตรวจเช็ค
            </h1>
            <p className="text-muted-foreground mt-2">
              บันทึกการตรวจเช็คสภาพรถทั้งหมดที่บันทึกไปแล้ว
            </p>
          </div>
          <div className="flex gap-3">
            <Button onClick={() => setLocation("/inspection")} size="lg">
              + บันทึกการตรวจเช็คใหม่
            </Button>
            {records.length > 0 && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" size="lg" className="gap-2" data-testid="button-reset">
                    <Trash2 className="h-4 w-4" />
                    รีเซ็ตข้อมูล
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>ยืนยันการลบข้อมูล</AlertDialogTitle>
                    <AlertDialogDescription>
                      คุณแน่ใจหรือไม่ที่ต้องการลบข้อมูลการตรวจเช็คทั้งหมด ({records.length} รายการ)? การกระทำนี้ไม่สามารถย้อนกลับได้
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogCancel>ยกเลิก</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleResetData}
                    disabled={isResetting}
                    className="bg-destructive hover:bg-destructive/90"
                    data-testid="confirm-reset"
                  >
                    {isResetting ? "กำลังลบ..." : "ลบข้อมูลทั้งหมด"}
                  </AlertDialogAction>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : records.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <HistoryIcon className="h-12 w-12 mx-auto text-muted-foreground mb-4 opacity-50" />
              <p className="text-lg text-muted-foreground">ยังไม่มีบันทึกการตรวจเช็ค</p>
              <p className="text-sm text-muted-foreground">ลองเพิ่มบันทึกการตรวจเช็คสภาพรถใหม่</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {records.map((record) => (
              <Card key={record.id} className="hover:shadow-md transition-shadow" data-testid={`record-${record.id}`}>
                <CardContent className="pt-6">
                  <div className="grid md:grid-cols-5 gap-6">
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                        <Car className="h-4 w-4" />
                        เลขทะเบียน
                      </p>
                      <p className="text-lg font-semibold" data-testid={`car-no-${record.id}`}>{record.carNo}</p>
                      <Badge variant="secondary" className="mt-2">{record.vehicleType}</Badge>
                    </div>

                    <div className="space-y-1">
                      <p className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                        <User className="h-4 w-4" />
                        ผู้ตรวจเช็ค
                      </p>
                      <p className="text-lg font-semibold" data-testid={`driver-${record.id}`}>{record.driver}</p>
                    </div>

                    <div className="space-y-1">
                      <p className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        วันที่ตรวจ
                      </p>
                      <p className="text-lg font-semibold" data-testid={`date-${record.id}`}>
                        {new Date(record.inspectionDate).toLocaleDateString("th-TH")}
                      </p>
                    </div>

                    <div className="space-y-1">
                      <p className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                        <Gauge className="h-4 w-4" />
                        เลขไมล์
                      </p>
                      <p className="text-lg font-semibold" data-testid={`mileage-${record.id}`}>
                        {record.currentMileage.toLocaleString()} กม.
                      </p>
                    </div>

                    <div className="space-y-1">
                      <p className="text-sm font-medium text-muted-foreground">
                        บันทึกเมื่อ
                      </p>
                      <p className="text-sm text-muted-foreground" data-testid={`created-${record.id}`}>
                        {record.createdAt 
                          ? new Date(record.createdAt).toLocaleString("th-TH", { 
                              year: "numeric", 
                              month: "short", 
                              day: "numeric", 
                              hour: "2-digit", 
                              minute: "2-digit" 
                            })
                          : "-"}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
