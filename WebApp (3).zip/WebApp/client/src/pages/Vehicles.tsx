import Layout from "@/components/layout/Layout";
import { useState } from "react";
import { initialVehicles, Vehicle, VehicleType, VehicleStatus, vehicleTypes, vehicleStatusThai } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Trash2, Filter, MoreHorizontal, Fuel, Gauge } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

export default function Vehicles() {
  const [vehicles, setVehicles] = useState<Vehicle[]>(initialVehicles);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editStatusVehicleId, setEditStatusVehicleId] = useState<string | null>(null);

  // New Vehicle Form State
  const [newVehicle, setNewVehicle] = useState<Partial<Vehicle>>({
    type: "Ambulance",
    status: "Available",
    fuelLevel: 100,
    mileage: 0,
  });

  const handleStatusChange = (vehicleId: string, newStatus: VehicleStatus) => {
    setVehicles(vehicles.map(v => 
      v.id === vehicleId ? { ...v, status: newStatus } : v
    ));
    setEditStatusVehicleId(null);
    toast({
      title: "เปลี่ยนสถานะสำเร็จ",
      description: `เปลี่ยนสถานะเป็น ${vehicleStatusThai[newStatus]}`,
    });
  };

  const handleDelete = (id: string) => {
    setVehicles(vehicles.filter(v => v.id !== id));
    toast({
      title: "ลบข้อมูลสำเร็จ",
      description: "ข้อมูลยานพาหนะถูกลบออกจากระบบแล้ว",
    });
  };

  const handleAdd = () => {
    if (!newVehicle.licensePlate) return;
    
    const vehicle: Vehicle = {
      id: `v${Date.now()}`,
      licensePlate: newVehicle.licensePlate,
      type: newVehicle.type as VehicleType,
      status: newVehicle.status as VehicleStatus,
      mileage: Number(newVehicle.mileage) || 0,
      fuelLevel: Number(newVehicle.fuelLevel) || 100,
      lastMaintenance: new Date().toISOString().split('T')[0],
      nextMaintenanceDue: (Number(newVehicle.mileage) || 0) + 5000,
      purchaseYear: new Date().getFullYear(),
    };

    setVehicles([...vehicles, vehicle]);
    setIsAddOpen(false);
    setNewVehicle({
      type: "Ambulance",
      status: "Available",
      fuelLevel: 100,
      mileage: 0,
      licensePlate: ""
    });
    toast({
      title: "เพิ่มข้อมูลสำเร็จ",
      description: `เพิ่มรถทะเบียน ${vehicle.licensePlate} เข้าสู่ระบบแล้ว`,
    });
  };

  const filteredVehicles = vehicles.filter(v => {
    const matchesSearch = v.licensePlate.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          v.driver?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "all" || v.type === filterType;
    return matchesSearch && matchesType;
  });

  const getStatusColor = (status: VehicleStatus) => {
    switch (status) {
      case "Available": return "bg-emerald-500/15 text-emerald-700 hover:bg-emerald-500/25 border-emerald-200";
      case "In Use": return "bg-blue-500/15 text-blue-700 hover:bg-blue-500/25 border-blue-200";
      case "Maintenance": return "bg-amber-500/15 text-amber-700 hover:bg-amber-500/25 border-amber-200";
      case "Out of Service": return "bg-red-500/15 text-red-700 hover:bg-red-500/25 border-red-200";
      default: return "bg-gray-500/15 text-gray-700";
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-primary">ข้อมูลยานพาหนะ</h1>
            <p className="text-muted-foreground">จัดการข้อมูลรถ ทะเบียน และสถานะการใช้งาน</p>
          </div>
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 shadow-lg shadow-primary/20">
                <Plus className="h-4 w-4" /> เพิ่มรถใหม่
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>เพิ่มยานพาหนะใหม่</DialogTitle>
                <DialogDescription>
                  กรอกข้อมูลเบื้องต้นของรถเพื่อนำเข้าระบบ
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="plate">เลขทะเบียน</Label>
                  <Input 
                    id="plate" 
                    value={newVehicle.licensePlate || ""} 
                    onChange={(e) => setNewVehicle({...newVehicle, licensePlate: e.target.value})}
                    placeholder="กก 1234" 
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="type">ประเภทรถ</Label>
                  <Select 
                    value={newVehicle.type} 
                    onValueChange={(val) => setNewVehicle({...newVehicle, type: val as VehicleType})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="เลือกประเภท" />
                    </SelectTrigger>
                    <SelectContent>
                      {vehicleTypes.map(t => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="mileage">เลขไมล์เริ่มต้น</Label>
                    <Input 
                      id="mileage" 
                      type="number" 
                      value={newVehicle.mileage} 
                      onChange={(e) => setNewVehicle({...newVehicle, mileage: Number(e.target.value)})}
                    />
                  </div>
                  <div className="grid gap-2">
                     <Label htmlFor="status">สถานะเริ่มต้น</Label>
                     <Select 
                        value={newVehicle.status} 
                        onValueChange={(val) => setNewVehicle({...newVehicle, status: val as VehicleStatus})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Available">Available</SelectItem>
                          <SelectItem value="Maintenance">Maintenance</SelectItem>
                        </SelectContent>
                      </Select>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddOpen(false)}>ยกเลิก</Button>
                <Button onClick={handleAdd}>บันทึกข้อมูล</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row gap-4 md:items-center justify-between">
               <CardTitle className="text-lg font-medium">รายการยานพาหนะทั้งหมด ({filteredVehicles.length})</CardTitle>
               <div className="flex gap-2">
                 <div className="relative w-full md:w-64">
                   <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                   <Input 
                      placeholder="ค้นหาทะเบียน หรือ คนขับ..." 
                      className="pl-9 bg-muted/40" 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                   />
                 </div>
                 <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-[180px]">
                      <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                      <SelectValue placeholder="ประเภทรถ" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ทั้งหมด</SelectItem>
                      {vehicleTypes.map(t => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                 </Select>
               </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ทะเบียน</TableHead>
                    <TableHead>ประเภท</TableHead>
                    <TableHead>สถานะ</TableHead>
                    <TableHead>ผู้ขับขี่ล่าสุด</TableHead>
                    <TableHead className="text-right">เลขไมล์ (กม.)</TableHead>
                    <TableHead className="text-right">ระดับน้ำมัน</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredVehicles.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center h-24 text-muted-foreground">
                        ไม่พบข้อมูลยานพาหนะ
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredVehicles.map((vehicle) => (
                      <TableRow key={vehicle.id} className="group">
                        <TableCell className="font-mono font-medium text-base">{vehicle.licensePlate}</TableCell>
                        <TableCell>{vehicle.type}</TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={cn("font-normal capitalize cursor-pointer hover:opacity-80", getStatusColor(vehicle.status))}
                            onClick={() => setEditStatusVehicleId(vehicle.id)}
                            data-testid={`status-${vehicle.id}`}
                          >
                            {vehicleStatusThai[vehicle.status]}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">{vehicle.driver || "-"}</TableCell>
                        <TableCell className="text-right font-mono">
                          <div className="flex items-center justify-end gap-2">
                            <Gauge className="h-3 w-3 text-muted-foreground opacity-50" />
                            {vehicle.mileage.toLocaleString()}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                             <span className={cn(
                               "font-mono",
                               vehicle.fuelLevel < 20 ? "text-red-600 font-bold" : ""
                             )}>{vehicle.fuelLevel}%</span>
                             <Fuel className={cn("h-3 w-3", vehicle.fuelLevel < 20 ? "text-red-500" : "text-muted-foreground opacity-50")} />
                          </div>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>จัดการ</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">เปลี่ยนสถานะ</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => handleStatusChange(vehicle.id, "Available")} data-testid={`status-available-${vehicle.id}`}>
                                ✓ ใช้งานได้
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleStatusChange(vehicle.id, "In Use")} data-testid={`status-inuse-${vehicle.id}`}>
                                ◉ ออกปฏิบัติงาน
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleStatusChange(vehicle.id, "Maintenance")} data-testid={`status-maintenance-${vehicle.id}`}>
                                ⟳ เช็คตามระยะที่กำหนด
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleStatusChange(vehicle.id, "Out of Service")} data-testid={`status-outofservice-${vehicle.id}`}>
                                ✕ รอซ่อม
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>ดูประวัติการใช้งาน</DropdownMenuItem>
                              <DropdownMenuItem>แจ้งซ่อมบำรุง</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                className="text-destructive focus:text-destructive"
                                onClick={() => handleDelete(vehicle.id)}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                ลบข้อมูล
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
