import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { initialVehicles, maintenanceHistory } from "@/lib/mockData";
import { Car, CheckCircle, Clock, AlertTriangle, Fuel, Activity, TrendingUp, Wrench } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';

export default function Dashboard() {
  const vehicles = initialVehicles;
  
  // Stats
  const totalVehicles = vehicles.length;
  const availableVehicles = vehicles.filter(v => v.status === "Available").length;
  const inUseVehicles = vehicles.filter(v => v.status === "In Use").length;
  const maintenanceVehicles = vehicles.filter(v => v.status === "Maintenance").length;
  const outOfServiceVehicles = vehicles.filter(v => v.status === "Out of Service").length;

  const totalDistance = vehicles.reduce((sum, v) => sum + v.mileage, 0);
  const avgFuel = Math.round(vehicles.reduce((sum, v) => sum + v.fuelLevel, 0) / totalVehicles);

  // Chart Data
  const statusData = [
    { name: 'พร้อมใช้งาน', value: availableVehicles, color: 'var(--color-chart-2)' },
    { name: 'กำลังใช้งาน', value: inUseVehicles, color: 'var(--color-chart-4)' },
    { name: 'ซ่อมบำรุง', value: maintenanceVehicles, color: 'var(--color-chart-3)' },
    { name: 'งดใช้', value: outOfServiceVehicles, color: 'var(--color-chart-5)' },
  ];

  const typeData = [
    { name: 'รถตู้พยาบาล', count: vehicles.filter(v => v.type === "Ambulance").length },
    { name: 'รถตู้บริการ', count: vehicles.filter(v => v.type === "Service Van").length },
    { name: 'กระบะ 4 ประตู', count: vehicles.filter(v => v.type === "Pickup 4 Door").length },
    { name: 'กระบะ 4x4', count: vehicles.filter(v => v.type === "Pickup 4x4 Ambulance").length },
  ];

  return (
    <Layout>
      <div className="space-y-6 animate-in fade-in duration-500">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-primary">Dashboard</h1>
            <p className="text-muted-foreground mt-1">ภาพรวมสถานะยานพาหนะและการดำเนินงาน</p>
          </div>
          <div className="flex gap-2">
            <div className="text-sm font-medium bg-accent px-3 py-1 rounded-md text-accent-foreground flex items-center gap-2">
              <Clock className="h-4 w-4" />
              {new Date().toLocaleDateString('th-TH', { year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>
        </div>

        <Tabs defaultValue="operational" className="space-y-6">
          <TabsList className="bg-muted/50 p-1">
            <TabsTrigger value="operational" className="text-sm">เชิงปฏิบัติการ (Operational)</TabsTrigger>
            <TabsTrigger value="analytical" className="text-sm">เชิงวิเคราะห์ (Analytical)</TabsTrigger>
            <TabsTrigger value="strategic" className="text-sm">เชิงกลยุทธ์ (Strategic)</TabsTrigger>
          </TabsList>

          <TabsContent value="operational" className="space-y-6">
            {/* Key Metrics Row */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card className="shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-primary">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">รถทั้งหมด</CardTitle>
                  <Car className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalVehicles}</div>
                  <p className="text-xs text-muted-foreground">คัน</p>
                </CardContent>
              </Card>
              
              <Card className="shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-emerald-500">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">พร้อมใช้งาน</CardTitle>
                  <CheckCircle className="h-4 w-4 text-emerald-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-emerald-600">{availableVehicles}</div>
                  <p className="text-xs text-muted-foreground">
                    {Math.round((availableVehicles / totalVehicles) * 100)}% ของทั้งหมด
                  </p>
                </CardContent>
              </Card>

              <Card className="shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-amber-500">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">กำลังซ่อมบำรุง</CardTitle>
                  <Wrench className="h-4 w-4 text-amber-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-amber-600">{maintenanceVehicles}</div>
                  <p className="text-xs text-muted-foreground">รออะไหล่ / ดำเนินการ</p>
                </CardContent>
              </Card>

              <Card className="shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-blue-500">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">ระยะทางสะสมรวม</CardTitle>
                  <Activity className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold font-mono tracking-tight">
                    {totalDistance.toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">กิโลเมตร</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              {/* Vehicle Status Chart */}
              <Card className="col-span-4 shadow-sm">
                <CardHeader>
                  <CardTitle>สถานะรถปัจจุบัน</CardTitle>
                  <CardDescription>สัดส่วนสถานะของยานพาหนะทั้งหมดในระบบ</CardDescription>
                </CardHeader>
                <CardContent className="pl-2">
                  <div className="h-[300px] w-full flex items-center justify-center">
                     <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={statusData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={100}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {statusData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip 
                            formatter={(value, name) => [`${value} คัน`, name]}
                            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                          />
                        </PieChart>
                     </ResponsiveContainer>
                  </div>
                  <div className="flex justify-center gap-6 mt-4">
                    {statusData.map((item, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="text-muted-foreground">{item.name} ({item.value})</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Recent Activity / Alerts */}
              <Card className="col-span-3 shadow-sm">
                <CardHeader>
                  <CardTitle>การแจ้งเตือนด่วน</CardTitle>
                  <CardDescription>รายการที่ต้องดำเนินการทันที</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {vehicles.filter(v => v.status === "Maintenance").slice(0, 3).map(v => (
                      <div key={v.id} className="flex items-start gap-4 p-3 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-100 dark:border-amber-900/30">
                        <div className="p-2 bg-amber-100 dark:bg-amber-900/40 rounded-full text-amber-600">
                          <Wrench className="h-4 w-4" />
                        </div>
                        <div>
                          <h4 className="text-sm font-semibold text-foreground">กำลังซ่อมบำรุง: {v.licensePlate}</h4>
                          <p className="text-xs text-muted-foreground">{v.type} - ครบกำหนดซ่อมบำรุง</p>
                        </div>
                      </div>
                    ))}
                    
                    {vehicles.some(v => v.status === "Out of Service") && (
                       <div className="flex items-start gap-4 p-3 bg-red-50 dark:bg-red-950/20 rounded-lg border border-red-100 dark:border-red-900/30">
                        <div className="p-2 bg-red-100 dark:bg-red-900/40 rounded-full text-red-600">
                          <AlertTriangle className="h-4 w-4" />
                        </div>
                        <div>
                          <h4 className="text-sm font-semibold text-foreground">รถงดใช้งาน (Out of Service)</h4>
                          <p className="text-xs text-muted-foreground">มีรถ {outOfServiceVehicles} คันที่ไม่พร้อมใช้งานอย่างถาวร</p>
                        </div>
                      </div>
                    )}

                    <div className="flex items-start gap-4 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-100 dark:border-blue-900/30">
                      <div className="p-2 bg-blue-100 dark:bg-blue-900/40 rounded-full text-blue-600">
                        <Fuel className="h-4 w-4" />
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-foreground">ระดับน้ำมันเฉลี่ย</h4>
                        <p className="text-xs text-muted-foreground">เฉลี่ยทั้งกองยานพาหนะ: {avgFuel}%</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytical">
            <Card>
              <CardHeader>
                <CardTitle>วิเคราะห์ประเภทรถและการใช้งาน</CardTitle>
                <CardDescription>จำนวนรถแบ่งตามประเภท</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={typeData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" tick={{fontSize: 12}} />
                      <YAxis allowDecimals={false} />
                      <Tooltip cursor={{fill: 'transparent'}} />
                      <Bar dataKey="count" fill="var(--color-primary)" radius={[4, 4, 0, 0]} barSize={60} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="strategic">
            <div className="grid gap-6 md:grid-cols-3">
               <Card>
                 <CardHeader>
                   <CardTitle className="flex items-center gap-2">
                     <TrendingUp className="h-5 w-5 text-emerald-500"/>
                     เป้าหมายลดค่าใช้จ่าย
                   </CardTitle>
                 </CardHeader>
                 <CardContent>
                   <div className="text-3xl font-bold text-emerald-600">-15%</div>
                   <p className="text-sm text-muted-foreground mt-2">เป้าหมายลดค่าซ่อมบำรุงต่อปี</p>
                   <div className="h-2 w-full bg-secondary mt-4 rounded-full overflow-hidden">
                     <div className="h-full bg-emerald-500 w-[65%]"></div>
                   </div>
                   <p className="text-xs text-right mt-1 text-muted-foreground">ความคืบหน้า 65%</p>
                 </CardContent>
               </Card>
               
               <Card>
                 <CardHeader>
                   <CardTitle className="flex items-center gap-2">
                     <Activity className="h-5 w-5 text-blue-500"/>
                     ประสิทธิภาพการใช้รถ
                   </CardTitle>
                 </CardHeader>
                 <CardContent>
                   <div className="text-3xl font-bold text-blue-600">85%</div>
                   <p className="text-sm text-muted-foreground mt-2">Utilization Rate เฉลี่ย</p>
                   <div className="h-2 w-full bg-secondary mt-4 rounded-full overflow-hidden">
                     <div className="h-full bg-blue-500 w-[85%]"></div>
                   </div>
                   <p className="text-xs text-right mt-1 text-muted-foreground">อยู่ในเกณฑ์ดี</p>
                 </CardContent>
               </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
