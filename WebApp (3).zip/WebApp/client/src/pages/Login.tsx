import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Car } from "lucide-react";
import bgImage from "@assets/generated_images/modern_abstract_fleet_management_background.png";

export default function Login() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Mock login delay
    setTimeout(() => {
      setIsLoading(false);
      setLocation("/dashboard");
    }, 1000);
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-background">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={bgImage} 
          alt="Background" 
          className="w-full h-full object-cover opacity-40 grayscale-[20%]"
        />
        <div className="absolute inset-0 bg-gradient-to-tr from-primary/90 to-primary/40 backdrop-blur-[2px]" />
      </div>

      <div className="relative z-10 w-full max-w-md px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="border-white/10 bg-white/95 backdrop-blur shadow-2xl">
            <CardHeader className="space-y-1 text-center pb-8">
              <div className="flex justify-center mb-4">
                <div className="h-12 w-12 rounded-xl bg-primary flex items-center justify-center text-primary-foreground shadow-lg">
                  <Car className="h-7 w-7" />
                </div>
              </div>
              <CardTitle className="text-2xl font-bold tracking-tight text-primary">FleetTrack</CardTitle>
              <CardDescription className="text-muted-foreground text-base">
                ระบบบริหารจัดการยานพาหนะ
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email">ชื่อผู้ใช้งาน</Label>
                  <Input 
                    id="email" 
                    placeholder="admin" 
                    defaultValue="admin"
                    className="bg-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">รหัสผ่าน</Label>
                  <Input 
                    id="password" 
                    type="password" 
                    placeholder="••••••••" 
                    defaultValue="password"
                    className="bg-white"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="remember" />
                  <label
                    htmlFor="remember"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    จำรหัสผ่าน
                  </label>
                </div>
                <Button 
                  type="submit" 
                  className="w-full text-base font-medium h-11"
                  disabled={isLoading}
                >
                  {isLoading ? "กำลังเข้าสู่ระบบ..." : "เข้าสู่ระบบ"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
        
        <div className="mt-6 text-center text-white/60 text-sm">
          © 2025 FleetTrack Management System
        </div>
      </div>
    </div>
  );
}
