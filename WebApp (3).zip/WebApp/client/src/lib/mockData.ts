import { format, addDays, subDays } from "date-fns";

export type VehicleType = "Ambulance" | "Service Van" | "Pickup 4 Door" | "Pickup 4x4 Ambulance";

export type VehicleStatus = "Available" | "In Use" | "Maintenance" | "Out of Service";

export interface Vehicle {
  id: string;
  licensePlate: string;
  type: VehicleType;
  status: VehicleStatus;
  mileage: number;
  fuelLevel: number; // 0-100
  lastMaintenance: string;
  nextMaintenanceDue: number; // mileage
  driver?: string;
  purchaseYear: number;
  image?: string;
}

export interface MaintenanceRecord {
  id: string;
  vehicleId: string;
  date: string;
  description: string;
  cost: number;
  mileageAtService: number;
  type: "Routine" | "Repair" | "Accident";
  technician?: string;
}

export interface Driver {
  id: string;
  name: string;
  status: "Active" | "Off Duty";
}

// Mock Data based on prompt
export const vehicleTypes: VehicleType[] = [
  "Ambulance",
  "Service Van",
  "Pickup 4 Door",
  "Pickup 4x4 Ambulance"
];

export const drivers: Driver[] = [
  { id: "d1", name: "นายประดิษฐ์ โปเสี้ยว", status: "Active" },
  { id: "d2", name: "นายธนวัฒน์ ฝอยทอง", status: "Active" },
  { id: "d3", name: "นายไกรสร อริยวงค์", status: "Off Duty" },
  { id: "d4", name: "นายศุภชัย ลือสนั่น", status: "Active" },
  { id: "d5", name: "นายไกรศิริ ดวงสนิท", status: "Active" },
  { id: "d6", name: "นายวิวัฒน์ หอมศักดิ์", status: "Off Duty" },
  { id: "d7", name: "นายเกล้าเพชร คล่องแคล่ว", status: "Active" },
  { id: "d8", name: "นายวีระ ประทุมแสง", status: "Active" },
];

// Inspectors list - exportable for management
export const defaultInspectors = [
  "นายประดิษฐ์ โปเสี้ยว",
  "นายธนวัฒน์ ฝอยทอง",
  "นายไกรสร อริยวงค์",
  "นายศุภชัย ลือสนั่น",
  "นายไกรศิริ ดวงสนิท",
  "นายวิวัฒน์ หอมศักดิ์",
  "นายเกล้าเพชร คล่องแคล่ว",
  "นายวีระ ประทุมแสง"
];

// Empty initial vehicles - start fresh without mock data
export const initialVehicles: Vehicle[] = [];

export const vehicleStatusThai: Record<VehicleStatus, string> = {
  "Available": "ใช้งานได้",
  "In Use": "ออกปฏิบัติงาน",
  "Maintenance": "เช็คตามระยะที่กำหนด",
  "Out of Service": "รอซ่อม"
};

export const maintenanceHistory: MaintenanceRecord[] = [
  { id: "m1", vehicleId: "v3", date: "2025-02-15", description: "เปลี่ยนถ่ายน้ำมันเครื่อง และไส้กรอง", cost: 3500, mileageAtService: 150200, type: "Routine" },
  { id: "m2", vehicleId: "v7", date: "2025-01-20", description: "ซ่อมช่วงล่างและระบบเบรค", cost: 12000, mileageAtService: 209000, type: "Repair" },
  { id: "m3", vehicleId: "v11", date: "2025-02-10", description: "เปลี่ยนยาง 4 เส้น", cost: 18000, mileageAtService: 132000, type: "Routine" },
  { id: "m4", vehicleId: "v1", date: "2024-12-15", description: "เช็คระยะ 120,000 กม.", cost: 5500, mileageAtService: 125000, type: "Routine" },
  { id: "m5", vehicleId: "v2", date: "2025-01-10", description: "เปลี่ยนแบตเตอรี่", cost: 2500, mileageAtService: 89000, type: "Repair" },
];

export const usageLogs = [
  { id: "u1", vehicleId: "v2", date: format(new Date(), "yyyy-MM-dd"), driver: "นายประดิษฐ์ โปเสี้ยว", destination: "โรงพยาบาลศูนย์", purpose: "รับผู้ป่วยฉุกเฉิน" },
  { id: "u2", vehicleId: "v5", date: format(new Date(), "yyyy-MM-dd"), driver: "นายธนวัฒน์ ฝอยทอง", destination: "จุดตรวจพื้นที่ 4", purpose: "ตรวจการณ์" },
  { id: "u3", vehicleId: "v9", date: format(subDays(new Date(), 1), "yyyy-MM-dd"), driver: "นายศุภชัย ลือสนั่น", destination: "ศูนย์ซ่อมบำรุง", purpose: "ส่งซ่อม" },
];
