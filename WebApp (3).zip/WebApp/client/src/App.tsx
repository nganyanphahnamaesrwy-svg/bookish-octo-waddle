import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import Vehicles from "@/pages/Vehicles";
import Maintenance from "@/pages/Maintenance";
import InspectionForm from "@/pages/InspectionForm";
import InspectionHistory from "@/pages/InspectionHistory";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Login} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/vehicles" component={Vehicles} />
      <Route path="/maintenance" component={Maintenance} />
      <Route path="/inspection" component={InspectionForm} />
      <Route path="/inspection-history" component={InspectionHistory} />
      
      {/* Placeholder routes for ones not fully implemented yet but in sidebar */}
      <Route path="/safety" component={Dashboard} />
      <Route path="/reports" component={Dashboard} />
      <Route path="/strategy" component={Dashboard} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
