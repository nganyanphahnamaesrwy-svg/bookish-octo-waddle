import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Car,
  Wrench,
  FileText,
  ClipboardCheck,
  Settings,
  LogOut,
  Menu,
  X,
  ShieldAlert,
  PieChart
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface SidebarProps {
  collapsed?: boolean;
}

export function Sidebar({ collapsed }: SidebarProps) {
  const [location] = useLocation();

  const navItems = [
    { href: "/dashboard", icon: LayoutDashboard, label: "แดชบอร์ด" },
    { href: "/vehicles", icon: Car, label: "ข้อมูลยานพาหนะ" },
    { href: "/inspection", icon: ClipboardCheck, label: "ฟอร์มตรวจเช็คสภาพรถ" },
    { href: "/inspection-history", icon: FileText, label: "ประวัติการตรวจเช็ค" },
    { href: "/maintenance", icon: Wrench, label: "การซ่อมบำรุง" },
    { href: "/safety", icon: ShieldAlert, label: "ความปลอดภัย" },
    { href: "/reports", icon: FileText, label: "รายงานผู้บริหาร" },
    { href: "/strategy", icon: PieChart, label: "กลยุทธ์ & เป้าหมาย" },
  ];

  return (
    <div className={cn("flex h-full flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border", collapsed ? "w-16" : "w-64")}>
      <div className="flex h-16 items-center px-6 border-b border-sidebar-border/50">
        <div className="flex items-center gap-2 font-bold text-xl tracking-tight">
          <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground">
            <Car className="h-5 w-5" />
          </div>
          {!collapsed && <span>FleetTrack</span>}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-4">
        <nav className="grid gap-1 px-2">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <a
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  location === item.href
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                )}
              >
                <item.icon className="h-4 w-4" />
                {!collapsed && <span>{item.label}</span>}
              </a>
            </Link>
          ))}
        </nav>
      </div>

      <div className="border-t border-sidebar-border/50 p-4">
        <Link href="/">
          <Button variant="ghost" className="w-full justify-start gap-3 text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50">
            <LogOut className="h-4 w-4" />
            {!collapsed && <span>ออกจากระบบ</span>}
          </Button>
        </Link>
      </div>
    </div>
  );
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      {/* Desktop Sidebar */}
      <div className="hidden md:block h-full">
        <Sidebar />
      </div>

      {/* Mobile Sidebar */}
      <div className="md:hidden absolute top-4 left-4 z-50">
        <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="md:hidden">
              <Menu className="h-4 w-4" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-64 border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
             <Sidebar />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="h-16 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 px-6 flex items-center justify-between md:justify-end shrink-0 z-10">
           <div className="flex items-center gap-4">
             <div className="text-sm text-muted-foreground hidden md:block">
               ยินดีต้อนรับ, ผู้ดูแลระบบ
             </div>
             <div className="h-8 w-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-medium text-xs">
               AD
             </div>
           </div>
        </header>
        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-7xl space-y-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
